#DEVOPS course for couth ll's 2021
This repo is for educational porpouse, ucc-devops its name.

by: andrees97
