#include <stdio.h>
#include <math.h>
#include <iostream>

using namespace std;

int main() {

	int ivalor = 20;
	int icontador = 0;
	int i = 0

	cout << "+-----------Programa Hilo------------+" << endl;
	for(int i = 1; i <= ivalor; i++){
		icontador += i;
		count << "Ciclo for i = " << icontador << endl;
	}

	cout << "+------------- Fin del programa -----------+ " << endl;

	return 0;
}
