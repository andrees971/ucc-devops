
    sqrAreaCuadrado = sqrt(areaCuadrado);
    printf("\nLa raiz del area del cuadrado es: %f", sqrAreaCuadrado);

    /*Triangulo*/
    sqrAreaTriangulo = sqrt(areaTriangulo);
    printf("\nLa raiz del del area del triangulo es de: %f", sqrAreaTriangulo);

    /*Circulo*/
    sqrAreaCirculo = sqrt(areaCirculo);
    printf("\nLa raiz del El area del circulo es de: %f", sqrAreaCirculo);
}
